% Generates a CSV with the numerial features from the mutagen dataset. Usage:  w('Mutagen_Num.CSV').


write_pos:-
    example(active(D), 1, _),
    ind1(D, Ind1),
    inda(D, Inda),
    logp(D, Logp),
    lumo(D, Lumo),
    write(D), write(', '),
    write(Ind1), write(', '), 
    write(Inda), write(', '), 
    write(Logp), write(', '), 
    write(Lumo), write(', '),
    write('active'), nl,
    fail.
write_pos.

write_neg:-
    example(active(D), -1, _),
    ind1(D, Ind1),
    inda(D, Inda),
    logp(D, Logp),
    lumo(D, Lumo),
    write(D), write(', '),
    write(Ind1), write(', '), 
    write(Inda), write(', '), 
    write(Logp), write(', '), 
    write(Lumo), write(', '),
    write('inactive'), nl,
    fail.
write_neg.
   
w(OutputFile):-
    tell(OutputFile),
    write('id, ind1, inda, logp, lumo, activity'),nl,
    write_pos,
    write_neg,
    told.
     

% test 1 examples
example(active(d112), 1, 1).
example(active(d20), 1, 1).
example(active(d109), 1, 1).
example(active(d25), 1, 1).
example(active(d26), 1, 1).
example(active(d1), 1, 1).
example(active(d177), 1, 1).
example(active(d91), 1, 1).
example(active(d162), 1, 1).
example(active(d18), 1, 1).
example(active(d52), 1, 1).
example(active(d57), 1, 1).
example(active(d48), 1, 1).
example(active(d183), 1, 1).
example(active(d37), 1, 1).
example(active(d24), 1, 1).
example(active(d60), 1, 1).
example(active(d33), 1, 1).
example(active(d104), 1, 1).
example(active(d64), 1, 1).

example(active(d88), -1, 1).
example(active(d111), -1, 1).
example(active(d160), -1, 1).
example(active(d34), -1, 1).
example(active(d76), -1, 1).
example(active(d156), -1, 1).

% test 2 examples

example(active(d173), 1, 2).
example(active(d56), 1, 2).
example(active(d10), 1, 2).
example(active(d29), 1, 2).
example(active(d159), 1, 2).
example(active(d153), 1, 2).
example(active(d167), 1, 2).
example(active(d172), 1, 2).
example(active(d35), 1, 2).
example(active(d105), 1, 2).
example(active(d107), 1, 2).
example(active(d180), 1, 2).

example(active(d132), -1, 2).
example(active(d14), -1, 2).
example(active(d138), -1, 2).
example(active(d131), -1, 2).
example(active(d42), -1, 2).
example(active(d78), -1, 2).

% test 3 examples

example(active(d44), 1, 3).
example(active(d86), 1, 3).
example(active(d71), 1, 3).
example(active(d31), 1, 3).
example(active(d176), 1, 3).
example(active(d79), 1, 3).
example(active(d145), 1, 3).
example(active(d68), 1, 3).
example(active(d41), 1, 3).

example(active(d129), -1, 3).
example(active(d3), -1, 3).
example(active(d143), -1, 3).
example(active(d7), -1, 3).
example(active(d98), -1, 3).
example(active(d100), -1, 3).
example(active(d114), -1, 3).
example(active(d124), -1, 3).
example(active(d113), -1, 3).

% test 4

example(active(d174), 1, 4).
example(active(d128), 1, 4).
example(active(d90), 1, 4).
example(active(d47), 1, 4).
example(active(d54), 1, 4).
example(active(d49), 1, 4).
example(active(d161), 1, 4).
example(active(d148), 1, 4).
example(active(d21), 1, 4).
example(active(d82), 1, 4).
example(active(d137), 1, 4).
example(active(d69), 1, 4).
example(active(d53), 1, 4).
example(active(d67), 1, 4).
example(active(d121), 1, 4).
example(active(d22), 1, 4).

example(active(d123), -1, 4).
example(active(d39), -1, 4).

% test 5

example(active(d16), 1, 5).
example(active(d63), 1, 5).
example(active(d12), 1, 5).
example(active(d30), 1, 5).
example(active(d127), 1, 5).
example(active(d170), 1, 5).
example(active(d83), 1, 5).
example(active(d59), 1, 5).
example(active(d61), 1, 5).
example(active(d178), 1, 5).

example(active(d144), -1, 5).
example(active(d182), -1, 5).
example(active(d66), -1, 5).
example(active(d147), -1, 5).
example(active(d65), -1, 5).
example(active(d84), -1, 5).
example(active(d188), -1, 5).
example(active(d55), -1, 5).

% test 6

example(active(d106), 1, 6).
example(active(d87), 1, 6).
example(active(d96), 1, 6).
example(active(d149), 1, 6).
example(active(d166), 1, 6).
example(active(d27), 1, 6).
example(active(d108), 1, 6).
example(active(d46), 1, 6).
example(active(d187), 1, 6).
example(active(d117), 1, 6).
example(active(d163), 1, 6).
example(active(d122), 1, 6).
example(active(d146), 1, 6).
example(active(d75), 1, 6).

example(active(d168), -1, 6).
example(active(d185), -1, 6).
example(active(d19), -1, 6).
example(active(d154), -1, 6).

% test 7

example(active(d95), 1, 7).
example(active(d51), 1, 7).
example(active(d97), 1, 7).
example(active(d72), 1, 7).
example(active(d85), 1, 7).
example(active(d164), 1, 7).
example(active(d158), 1, 7).
example(active(d81), 1, 7).
example(active(d11), 1, 7).
example(active(d115), 1, 7).
example(active(d152), 1, 7).
example(active(d92), 1, 7).

example(active(d155), -1, 7).
example(active(d40), -1, 7).
example(active(d110), -1, 7).
example(active(d186), -1, 7).
example(active(d62), -1, 7).
example(active(d150), -1, 7).

% test 8

example(active(d136), 1, 8).
example(active(d102), 1, 8).
example(active(d6), 1, 8).
example(active(d93), 1, 8).
example(active(d126), 1, 8).
example(active(d43), 1, 8).
example(active(d28), 1, 8).
example(active(d140), 1, 8).
example(active(d101), 1, 8).
example(active(d103), 1, 8).
example(active(d45), 1, 8).

example(active(d120), -1, 8).
example(active(d89), -1, 8).
example(active(d181), -1, 8).
example(active(d179), -1, 8).
example(active(d73), -1, 8).
example(active(d77), -1, 8).
example(active(d141), -1, 8).

% test 9

example(active(d58), 1, 9).
example(active(d32), 1, 9).
example(active(d8), 1, 9).
example(active(d74), 1, 9).
example(active(d184), 1, 9).
example(active(d134), 1, 9).
example(active(d80), 1, 9).
example(active(d23), 1, 9).
example(active(d118), 1, 9).
example(active(d94), 1, 9).
example(active(d157), 1, 9).

example(active(d133), -1, 9).
example(active(d142), -1, 9).
example(active(d5), -1, 9).
example(active(d36), -1, 9).
example(active(d17), -1, 9).
example(active(d70), -1, 9).
example(active(d119), -1, 9).

% test 10

example(active(d4), 1, 10).
example(active(d125), 1, 10).
example(active(d15), 1, 10).
example(active(d99), 1, 10).
example(active(d165), 1, 10).
example(active(d169), 1, 10).
example(active(d50), 1, 10).
example(active(d151), 1, 10).
example(active(d13), 1, 10).
example(active(d171), 1, 10).

example(active(d116), -1, 10).
example(active(d175), -1, 10).
example(active(d2), -1, 10).
example(active(d38), -1, 10).
example(active(d130), -1, 10).
example(active(d135), -1, 10).
example(active(d9), -1, 10).
example(active(d139), -1, 10).




ind1(d1,1.0).
ind1(d2,0.0).
ind1(d3,0.0).
ind1(d4,1.0).
ind1(d5,0.0).
ind1(d6,1.0).
ind1(d7,0.0).
ind1(d8,1.0).
ind1(d9,0.0).

ind1(d10,1.0).
ind1(d11,1.0).
ind1(d12,1.0).
ind1(d13,1.0).
ind1(d14,0.0).
ind1(d15,1.0).
ind1(d16,1.0).
ind1(d17,0.0).
ind1(d18,1.0).
ind1(d19,0.0).

ind1(d20,1.0).
ind1(d21,0.0).
ind1(d22,1.0).
ind1(d23,1.0).
ind1(d24,1.0).
ind1(d25,1.0).
ind1(d26,0.0).
ind1(d27,1.0).
ind1(d28,1.0).
ind1(d29,1.0).

ind1(d30,1.0).
ind1(d31,1.0).
ind1(d32,0.0).
ind1(d33,1.0).
ind1(d34,0.0).
ind1(d35,1.0).
ind1(d36,0.0).
ind1(d37,0.0).
ind1(d38,0.0).
ind1(d39,0.0).

ind1(d40,0.0).
ind1(d41,1.0).
ind1(d42,0.0).
ind1(d43,1.0).
ind1(d44,1.0).
ind1(d45,0.0).
ind1(d46,1.0).
ind1(d47,1.0).
ind1(d48,1.0).
ind1(d49,1.0).

ind1(d50,0.0).
ind1(d51,1.0).
ind1(d52,1.0).
ind1(d53,1.0).
ind1(d54,1.0).
ind1(d55,0.0).
ind1(d56,1.0).
ind1(d57,0.0).
ind1(d58,1.0).
ind1(d59,1.0).

ind1(d60,0.0).
ind1(d61,1.0).
ind1(d62,0.0).
ind1(d63,0.0).
ind1(d64,1.0).
ind1(d65,0.0).
ind1(d66,0.0).
ind1(d67,1.0).
ind1(d68,1.0).
ind1(d69,1.0).

ind1(d70,0.0).
ind1(d71,1.0).
ind1(d72,1.0).
ind1(d73,0.0).
ind1(d74,1.0).
ind1(d75,0.0).
ind1(d76,0.0).
ind1(d77,0.0).
ind1(d78,0.0).
ind1(d79,1.0).

ind1(d80,1.0).
ind1(d81,0.0).
ind1(d82,1.0).
ind1(d83,1.0).
ind1(d84,0.0).
ind1(d85,1.0).
ind1(d86,1.0).
ind1(d87,1.0).
ind1(d88,0.0).
ind1(d89,0.0).

ind1(d90,1.0).
ind1(d91,1.0).
ind1(d92,1.0).
ind1(d93,1.0).
ind1(d94,1.0).
ind1(d95,0.0).
ind1(d96,1.0).
ind1(d97,1.0).
ind1(d98,0.0).
ind1(d99,1.0).

ind1(d100,0.0).
ind1(d101,1.0).
ind1(d102,1.0).
ind1(d103,1.0).
ind1(d104,1.0).
ind1(d105,1.0).
ind1(d106,1.0).
ind1(d107,1.0).
ind1(d108,1.0).
ind1(d109,1.0).

ind1(d110,0.0).
ind1(d111,0.0).
ind1(d112,1.0).
ind1(d113,0.0).
ind1(d114,0.0).
ind1(d115,0.0).
ind1(d116,0.0).
ind1(d117,0.0).
ind1(d118,1.0).
ind1(d119,0.0).

ind1(d120,0.0).
ind1(d121,1.0).
ind1(d122,1.0).
ind1(d123,0.0).
ind1(d124,0.0).
ind1(d125,1.0).
ind1(d126,1.0).
ind1(d127,0.0).
ind1(d128,1.0).
ind1(d129,0.0).

ind1(d130,0.0).
ind1(d131,0.0).
ind1(d132,0.0).
ind1(d133,1.0).
ind1(d134,1.0).
ind1(d135,0.0).
ind1(d136,1.0).
ind1(d137,1.0).
ind1(d138,0.0).
ind1(d139,0.0).

ind1(d140,0.0).
ind1(d141,0.0).
ind1(d142,1.0).
ind1(d143,0.0).
ind1(d144,0.0).
ind1(d145,0.0).
ind1(d146,0.0).
ind1(d147,0.0).
ind1(d148,1.0).
ind1(d149,1.0).

ind1(d150,0.0).
ind1(d151,0.0).
ind1(d152,1.0).
ind1(d153,1.0).
ind1(d154,0.0).
ind1(d155,0.0).
ind1(d156,0.0).
ind1(d157,1.0).
ind1(d158,1.0).
ind1(d159,1.0).

ind1(d160,0.0).
ind1(d161,1.0).
ind1(d162,0.0).
ind1(d163,1.0).
ind1(d164,1.0).
ind1(d165,1.0).
ind1(d166,1.0).
ind1(d167,1.0).
ind1(d168,0.0).
ind1(d169,0.0).

ind1(d170,1.0).
ind1(d171,0.0).
ind1(d172,0.0).
ind1(d173,0.0).
ind1(d174,1.0).
ind1(d175,1.0).
ind1(d176,0.0).
ind1(d177,1.0).
ind1(d178,0.0).
ind1(d179,0.0).

ind1(d180,1.0).
ind1(d181,0.0).
ind1(d182,0.0).
ind1(d183,1.0).
ind1(d184,1.0).
ind1(d185,0.0).
ind1(d186,0.0).
ind1(d187,1.0).
ind1(d188,1.0).








ind1(d189,0.0).
ind1(d190,0.0).
ind1(d191,1.0).
ind1(d192,1.0).
ind1(d193,1.0).
ind1(d194,0.0).
ind1(d195,0.0).
ind1(d196,1.0).
ind1(d197,0.0).

ind1(e1,1.0).
ind1(e2,1.0).
ind1(e3,0.0).
ind1(e4,0.0).
ind1(e5,0.0).
ind1(e6,0.0).
ind1(e7,0.0).
ind1(e8,0.0).
ind1(e9,0.0).
ind1(e10,0.0).
ind1(e11,0.0).
ind1(e12,0.0).
ind1(e13,0.0).
ind1(e14,0.0).
ind1(e15,1.0).
ind1(e16,0.0).
ind1(e17,1.0).
ind1(e18,0.0).
ind1(e19,1.0).
ind1(e20,1.0).
ind1(e21,1.0).
ind1(e22,1.0).
ind1(e23,1.0).
ind1(e24,1.0).
ind1(e25,1.0).
ind1(e26,1.0).
ind1(e27,1.0).
ind1(f1,0.0).
ind1(f2,0.0).
ind1(f3,0.0).
ind1(f4,0.0).
ind1(f5,0.0).
ind1(f6,0.0).

inda(d1,0.0).
inda(d2,0.0).
inda(d3,0.0).
inda(d4,0.0).
inda(d5,0.0).
inda(d6,0.0).
inda(d7,0.0).
inda(d8,0.0).
inda(d9,0.0).

inda(d10,0.0).
inda(d11,0.0).
inda(d12,0.0).
inda(d13,0.0).
inda(d14,0.0).
inda(d15,0.0).
inda(d16,0.0).
inda(d17,0.0).
inda(d18,0.0).
inda(d19,0.0).

inda(d20,0.0).
inda(d21,0.0).
inda(d22,0.0).
inda(d23,1.0).
inda(d24,0.0).
inda(d25,0.0).
inda(d26,0.0).
inda(d27,0.0).
inda(d28,0.0).
inda(d29,0.0).

inda(d30,1.0).
inda(d31,0.0).
inda(d32,0.0).
inda(d33,0.0).
inda(d34,0.0).
inda(d35,0.0).
inda(d36,0.0).
inda(d37,0.0).
inda(d38,0.0).
inda(d39,0.0).

inda(d40,0.0).
inda(d41,0.0).
inda(d42,0.0).
inda(d43,0.0).
inda(d44,0.0).
inda(d45,0.0).
inda(d46,0.0).
inda(d47,0.0).
inda(d48,0.0).
inda(d49,0.0).

inda(d50,0.0).
inda(d51,0.0).
inda(d52,0.0).
inda(d53,0.0).
inda(d54,0.0).
inda(d55,0.0).
inda(d56,0.0).
inda(d57,0.0).
inda(d58,0.0).
inda(d59,1.0).

inda(d60,0.0).
inda(d61,0.0).
inda(d62,0.0).
inda(d63,0.0).
inda(d64,0.0).
inda(d65,0.0).
inda(d66,0.0).
inda(d67,0.0).
inda(d68,0.0).
inda(d69,0.0).

inda(d70,0.0).
inda(d71,0.0).
inda(d72,0.0).
inda(d73,0.0).
inda(d74,0.0).
inda(d75,0.0).
inda(d76,0.0).
inda(d77,0.0).
inda(d78,0.0).
inda(d79,0.0).

inda(d80,0.0).
inda(d81,0.0).
inda(d82,0.0).
inda(d83,0.0).
inda(d84,0.0).
inda(d85,1.0).
inda(d86,1.0).
inda(d87,0.0).
inda(d88,0.0).
inda(d89,0.0).

inda(d90,0.0).
inda(d91,0.0).
inda(d92,0.0).
inda(d93,0.0).
inda(d94,0.0).
inda(d95,0.0).
inda(d96,0.0).
inda(d97,0.0).
inda(d98,0.0).
inda(d99,0.0).

inda(d100,0.0).
inda(d101,0.0).
inda(d102,0.0).
inda(d103,0.0).
inda(d104,0.0).
inda(d105,0.0).
inda(d106,0.0).
inda(d107,0.0).
inda(d108,0.0).
inda(d109,0.0).

inda(d110,0.0).
inda(d111,0.0).
inda(d112,0.0).
inda(d113,0.0).
inda(d114,0.0).
inda(d115,0.0).
inda(d116,0.0).
inda(d117,0.0).
inda(d118,0.0).
inda(d119,0.0).

inda(d120,0.0).
inda(d121,0.0).
inda(d122,0.0).
inda(d123,0.0).
inda(d124,0.0).
inda(d125,0.0).
inda(d126,0.0).
inda(d127,0.0).
inda(d128,0.0).
inda(d129,0.0).

inda(d130,0.0).
inda(d131,0.0).
inda(d132,0.0).
inda(d133,0.0).
inda(d134,0.0).
inda(d135,0.0).
inda(d136,0.0).
inda(d137,0.0).
inda(d138,0.0).
inda(d139,0.0).

inda(d140,0.0).
inda(d141,0.0).
inda(d142,0.0).
inda(d143,0.0).
inda(d144,0.0).
inda(d145,0.0).
inda(d146,0.0).
inda(d147,0.0).
inda(d148,0.0).
inda(d149,0.0).

inda(d150,0.0).
inda(d151,0.0).
inda(d152,0.0).
inda(d153,0.0).
inda(d154,0.0).
inda(d155,0.0).
inda(d156,0.0).
inda(d157,0.0).
inda(d158,0.0).
inda(d159,0.0).

inda(d160,0.0).
inda(d161,0.0).
inda(d162,0.0).
inda(d163,0.0).
inda(d164,0.0).
inda(d165,0.0).
inda(d166,0.0).
inda(d167,0.0).
inda(d168,0.0).
inda(d169,0.0).

inda(d170,0.0).
inda(d171,0.0).
inda(d172,0.0).
inda(d173,0.0).
inda(d174,0.0).
inda(d175,0.0).
inda(d176,0.0).
inda(d177,0.0).
inda(d178,0.0).
inda(d179,0.0).

inda(d180,0.0).
inda(d181,0.0).
inda(d182,0.0).
inda(d183,0.0).
inda(d184,0.0).
inda(d185,0.0).
inda(d186,0.0).
inda(d187,0.0).
inda(d188,0.0).








inda(d189,0.0).
inda(d190,0.0).
inda(d191,0.0).
inda(d192,0.0).
inda(d193,0.0).
inda(d194,0.0).
inda(d195,0.0).
inda(d196,0.0).
inda(d197,0.0).

inda(e1,0.0).
inda(e2,0.0).
inda(e3,0.0).
inda(e4,0.0).
inda(e5,0.0).
inda(e6,0.0).
inda(e7,0.0).
inda(e8,0.0).
inda(e9,0.0).
inda(e10,0.0).
inda(e11,0.0).
inda(e12,0.0).
inda(e13,0.0).
inda(e14,0.0).
inda(e15,0.0).
inda(e16,0.0).
inda(e17,0.0).
inda(e18,0.0).
inda(e19,0.0).
inda(e20,0.0).
inda(e21,0.0).
inda(e22,0.0).
inda(e23,0.0).
inda(e24,0.0).
inda(e25,0.0).
inda(e26,0.0).
inda(e27,0.0).
inda(f1,0.0).
inda(f2,0.0).
inda(f3,0.0).
inda(f4,0.0).
inda(f5,0.0).
inda(f6,0.0).


logp(d8, 3.46).
logp(d16, 4.44).
logp(d21, 3.52).
logp(d22, 5.09).
logp(d23, 5.07).
logp(d29, 2.42).
logp(d30, 5.07).
logp(d32, 3).
logp(d33, 4.23).
logp(d35, 3.06).
logp(d37, 4.18).
logp(d44, 4.53).
logp(d47, 5.02).
logp(d74, 5.87).
logp(d81, 1.49).
logp(d85, 5.07).
logp(d91, 3.01).
logp(d92, 5.28).
logp(d93, 5.87).
logp(d97, 3.95).
logp(d99, 2.72).
logp(d102, 2.4).
logp(d103, 4.69).
logp(d106, 4.34).
logp(d108, 4.69).
logp(d118, 6.57).
logp(d121, 4.18).
logp(d134, 4.73).
logp(d145, 2.68).
logp(d158, 3.08).
logp(d161, 5.61).
logp(d162, 3).
logp(d167, 4.44).
logp(d170, 2.52).
logp(d176, 2.74).
logp(d180, 6.07).
logp(f4, -0.47).
logp(f5, 0.95).
logp(d2, 1.44).
logp(d17, 0.87).
logp(d42, 1.77).
logp(d70, 0.47).
logp(d77, 2.68).
logp(d89, 1.77).
logp(d98, 1.65).
logp(d111, 1.56).
logp(d114, 2.68).
logp(d119, 3.26).
logp(d120, 1.77).
logp(d130, 1.73).
logp(d131, 2.83).
logp(d132, 1.74).
logp(d138, 1.77).
logp(d141, 3.05).
logp(d144, 2.9).
logp(d147, 1.94).
logp(d186, 2.07).
logp(d188, 3.51).
logp(d189, 2.29).
logp(d196, 3.51).
logp(e4, 2.5).
logp(e5, 1.85).
logp(e8, 2.03).
logp(e12, 1.58).
logp(e14, 2.39).
logp(e18, 3.12).
logp(e22, 2.55).
logp(e25, 4.78).
logp(e26, 5.06).
logp(d1, 4.23).
logp(d4, 4.69).
logp(d6, 3.92).
logp(d10, 4.62).
logp(d11, 4.23).
logp(d12, 3.63).
logp(d13, 4.44).
logp(d15, 4.69).
logp(d18, 3.06).
logp(d20, 3.4).
logp(d24, 6.79).
logp(d25, 3.43).
logp(d26, 2.17).
logp(d27, 5.87).
logp(d28, 4.11).
logp(d31, 4.44).
logp(d41, 4.83).
logp(d43, 4.69).
logp(d45, 1.46).
logp(d46, 6.57).
logp(d48, 4.23).
logp(d49, 2.29).
logp(d50, 2.58).
logp(d51, 6.01).
logp(d52, 6.01).
logp(d53, 3.35).
logp(d54, 6.24).
logp(d56, 2.52).
logp(d57, 3.26).
logp(d58, 3.01).
logp(d59, 5.07).
logp(d60, 2.3).
logp(d61, 4.68).
logp(d63, 2.79).
logp(d64, 2.84).
logp(d67, 4.66).
logp(d68, 5.87).
logp(d69, 3.71).
logp(d71, 6.01).
logp(d72, 3.37).
logp(d75, 3.52).
logp(d79, 4.73).
logp(d80, 4.69).
logp(d82, 4.18).
logp(d83, 3.51).
logp(d86, 5.07).
logp(d87, 3.83).
logp(d90, 5.87).
logp(d94, 4.69).
logp(d95, 2.55).
logp(d96, 4.18).
logp(d101, 6.26).
logp(d104, 6.26).
logp(d105, 1.84).
logp(d107, 4.18).
logp(d109, 6.07).
logp(d112, 3.81).
logp(d115, 2.74).
logp(d117, 3.26).
logp(d122, 5.41).
logp(d125, 4.99).
logp(d126, 2.29).
logp(d127, 3.26).
logp(d128, 3.36).
logp(d136, 4.66).
logp(d137, 4.44).
logp(d140, 2.52).
logp(d146, 2.68).
logp(d148, 3.36).
logp(d149, 2.29).
logp(d151, 1.75).
logp(d152, 4.44).
logp(d153, 3.85).
logp(d157, 4.19).
logp(d159, 4.19).
logp(d163, 4.44).
logp(d164, 4.44).
logp(d165, 4.69).
logp(d166, 4.42).
logp(d169, 1.49).
logp(d171, 3).
logp(d172, 2.06).
logp(d173, 3.26).
logp(d174, 4.44).
logp(d177, 2.29).
logp(d178, 1.77).
logp(d182, 1.99).
logp(d183, 4.44).
logp(d184, 4.44).
logp(d187, 5.41).
logp(d190, 2.13).
logp(d191, 4.35).
logp(d194, 0.88).
logp(d197, 1.58).
logp(e1, 5.87).
logp(e2, 6.16).
logp(e27, 5.87).
logp(f1, 1.01).
logp(f2, 0.96).
logp(f3, 0.23).
logp(f6, -0.04).
logp(d3, 1.86).
logp(d5, 1.89).
logp(d7, 3.99).
logp(d9, 1.64).
logp(d14, 1.77).
logp(d19, 1.84).
logp(d34, 3.24).
logp(d36, 3.43).
logp(d38, 3.77).
logp(d39, 1.87).
logp(d40, 3.19).
logp(d55, 3.43).
logp(d62, 1.36).
logp(d65, 2.83).
logp(d66, 2.68).
logp(d73, 2.68).
logp(d76, 2.24).
logp(d78, 4.27).
logp(d84, 2.61).
logp(d88, 1.53).
logp(d100, 2.68).
logp(d110, 3).
logp(d113, 1.84).
logp(d116, 1.8).
logp(d123, 4.49).
logp(d124, 1.89).
logp(d129, 1.46).
logp(d133, 7.13).
logp(d135, 2.74).
logp(d139, 2.72).
logp(d142, 6.68).
logp(d143, 2.35).
logp(d150, -0.02).
logp(d154, 1.59).
logp(d155, 1.72).
logp(d156, 1.92).
logp(d160, 2.78).
logp(d168, 2.03).
logp(d175, 7.84).
logp(d179, 2.73).
logp(d181, 0.53).
logp(d185, 1.89).
logp(d192, 5.41).
logp(d193, 5.41).
logp(d195, 3.61).
logp(e3, 2.86).
logp(e6, 2.5).
logp(e7, 2.13).
logp(e9, 1.69).
logp(e10, 2.13).
logp(e11, 1.9).
logp(e13, 2.41).
logp(e15, 5.41).
logp(e16, 3.09).
logp(e17, 4.78).
logp(e19, 1.38).
logp(e20, 1.38).
logp(e21, 6.57).
logp(e23, 2.55).
logp(e24, 5.41).

lumo(d8, -1.437).
lumo(d16, -2.172).
lumo(d21, -1.665).
lumo(d22, -1.602).
lumo(d23, -2.164).
lumo(d29, -2.837).
lumo(d30, -2.005).
lumo(d32, -2.562).
lumo(d33, -1.591).
lumo(d35, -1.176).
lumo(d37, -1.428).
lumo(d44, -1.265).
lumo(d47, -1.88).
lumo(d74, -1.689).
lumo(d81, -1.937).
lumo(d85, -2.113).
lumo(d91, -2.032).
lumo(d92, -1.208).
lumo(d93, -1.729).
lumo(d97, -1.361).
lumo(d99, -2.159).
lumo(d102, -3.172).
lumo(d103, -1.487).
lumo(d106, -1.607).
lumo(d108, -1.676).
lumo(d118, -1.8).
lumo(d121, -2.68).
lumo(d134, -1.951).
lumo(d145, -1.178).
lumo(d158, -1.34).
lumo(d161, -2.221).
lumo(d162, -2.687).
lumo(d167, -2.31).
lumo(d170, -2.113).
lumo(d176, -1.304).
lumo(d180, -2.182).
lumo(f4, -1.645).
lumo(f5, -1.526).
lumo(d2, -1.429).
lumo(d17, -0.529).
lumo(d42, -1.19).
lumo(d70, -1.786).
lumo(d77, -1.029).
lumo(d89, -1.028).
lumo(d98, -1.598).
lumo(d111, -1.687).
lumo(d114, -1.148).
lumo(d119, -1.995).
lumo(d120, -0.937).
lumo(d130, -0.93).
lumo(d131, -1.538).
lumo(d132, -1.499).
lumo(d138, -1.157).
lumo(d141, -1.228).
lumo(d144, -1.288).
lumo(d147, -0.937).
lumo(d186, -0.574).
lumo(d188, -0.872).
lumo(d189, -3.025).
lumo(d196, -1.092).
lumo(e4, -0.746).
lumo(e5, -1.089).
lumo(e8, -1.117).
lumo(e12, -1.834).
lumo(e14, -1.36).
lumo(e18, -1.538).
lumo(e22, -1.636).
lumo(e25, -1.748).
lumo(e26, -1.82).
lumo(d1, -1.246).
lumo(d4, -1.591).
lumo(d6, -3.406).
lumo(d10, -1.387).
lumo(d11, -1.254).
lumo(d12, -1.627).
lumo(d13, -2.292).
lumo(d15, -1.698).
lumo(d18, -1.861).
lumo(d20, -1.764).
lumo(d24, -1.728).
lumo(d25, -1.398).
lumo(d26, -2.072).
lumo(d27, -1.801).
lumo(d28, -1.558).
lumo(d31, -2.055).
lumo(d41, -1.6).
lumo(d43, -1.57).
lumo(d45, -2.227).
lumo(d46, -1.804).
lumo(d48, -1.616).
lumo(d49, -2.808).
lumo(d50, -1.932).
lumo(d51, -2.184).
lumo(d52, -2.189).
lumo(d53, -2.155).
lumo(d54, -1.464).
lumo(d56, -2.234).
lumo(d57, -2.242).
lumo(d58, -1.991).
lumo(d59, -2.14).
lumo(d60, -2.468).
lumo(d61, -1.556).
lumo(d63, -3.768).
lumo(d64, -2.338).
lumo(d67, -1.536).
lumo(d68, -1.766).
lumo(d69, -1.929).
lumo(d71, -2.095).
lumo(d72, -1.448).
lumo(d75, -1.87).
lumo(d79, -1.26).
lumo(d80, -1.329).
lumo(d82, -2.71).
lumo(d83, -1.145).
lumo(d86, -1.918).
lumo(d87, -1.488).
lumo(d90, -1.62).
lumo(d94, -1.585).
lumo(d95, -2.434).
lumo(d96, -2.871).
lumo(d101, -1.598).
lumo(d104, -1.546).
lumo(d105, -1.749).
lumo(d107, -2.791).
lumo(d109, -2.284).
lumo(d112, -1.208).
lumo(d115, -1.161).
lumo(d117, -2.142).
lumo(d122, -1.61).
lumo(d125, -1.256).
lumo(d126, -2.718).
lumo(d127, -2.196).
lumo(d128, -2.149).
lumo(d136, -1.685).
lumo(d137, -2.263).
lumo(d140, -1.751).
lumo(d146, -1.102).
lumo(d148, -2.158).
lumo(d149, -2.87).
lumo(d151, -1.411).
lumo(d152, -2.191).
lumo(d153, -1.151).
lumo(d157, -1.623).
lumo(d159, -1.742).
lumo(d163, -1.974).
lumo(d164, -2.306).
lumo(d165, -1.522).
lumo(d166, -1.709).
lumo(d169, -2.17).
lumo(d171, -2.508).
lumo(d172, -1.487).
lumo(d173, -2.328).
lumo(d174, -2.209).
lumo(d177, -2.614).
lumo(d178, -1.213).
lumo(d182, -1.366).
lumo(d183, -2.294).
lumo(d184, -2.074).
lumo(d187, -1.276).
lumo(d190, -0.798).
lumo(d191, -2.138).
lumo(d194, -0.857).
lumo(d197, -1.293).
lumo(e1, -1.767).
lumo(e2, -1.35).
lumo(e27, -1.845).
lumo(f1, -1.785).
lumo(f2, -1.851).
lumo(f3, -1.412).
lumo(f6, -1.503).
lumo(d3, -1.456).
lumo(d5, -1.59).
lumo(d7, -1.144).
lumo(d9, -0.982).
lumo(d14, -1.289).
lumo(d19, -1.478).
lumo(d34, -1.451).
lumo(d36, -1.24).
lumo(d38, -1.228).
lumo(d39, -1.443).
lumo(d40, -1.266).
lumo(d55, -1.177).
lumo(d62, -0.923).
lumo(d65, -1.952).
lumo(d66, -0.959).
lumo(d73, -0.648).
lumo(d76, -1.069).
lumo(d78, -1.276).
lumo(d84, -1.256).
lumo(d88, -1.605).
lumo(d100, -1.034).
lumo(d110, -2.14).
lumo(d113, -1.491).
lumo(d116, -1.37).
lumo(d123, -1.056).
lumo(d124, -1.596).
lumo(d129, -1.592).
lumo(d133, -1.492).
lumo(d135, -1.562).
lumo(d139, -1.019).
lumo(d142, -1.474).
lumo(d143, -1.046).
lumo(d150, -0.995).
lumo(d154, -1.362).
lumo(d155, -1.737).
lumo(d156, -0.854).
lumo(d160, -1.691).
lumo(d168, -1.112).
lumo(d175, -1.616).
lumo(d179, -1.889).
lumo(d181, -0.727).
lumo(d185, -2.09).
lumo(d192, -1.429).
lumo(d193, -1.478).
lumo(d195, -1.465).
lumo(e3, -0.56).
lumo(e6, -0.868).
lumo(e7, -1.05).
lumo(e9, -1.321).
lumo(e10, -1.125).
lumo(e11, -1.358).
lumo(e13, -1.306).
lumo(e15, -1.723).
lumo(e16, -1.351).
lumo(e17, -1.755).
lumo(e19, -1.392).
lumo(e20, -1.447).
lumo(e21, -1.717).
lumo(e23, -1.808).
lumo(e24, -1.113).
